import { PokemonDetailPage } from '@/src/pages/pokemon-detail/PokemonDetailPage'

export default PokemonDetailPage
