import { PokemonListPage } from '@/src/pages/pokemon-list/PokemonListPage'

export default PokemonListPage
