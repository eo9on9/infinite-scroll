export type Generation = 1 | 2 | 3 | 4 | 5
