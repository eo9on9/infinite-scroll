export interface PokemonSummary {
  name: string
  url: string
}
