import { HomePage } from '@/src/pages/home/HomePage'

export default HomePage
