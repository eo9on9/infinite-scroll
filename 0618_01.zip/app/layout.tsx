import { RootLayout } from '@/src/app/ui/RootLayout'

export default RootLayout
